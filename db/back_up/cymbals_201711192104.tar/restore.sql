--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.10
-- Dumped by pg_dump version 9.5.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.retailers DROP CONSTRAINT fk_rails_d5e06be6ba;
DROP INDEX public.index_retailers_on_maker_id;
DROP INDEX public.index_makers_on_code;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_pkey;
ALTER TABLE ONLY public.makers DROP CONSTRAINT makers_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE public.retailers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.makers ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.retailers_id_seq;
DROP TABLE public.retailers;
DROP SEQUENCE public.makers_id_seq;
DROP TABLE public.makers;
DROP TABLE public.ar_internal_metadata;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: yg
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE ar_internal_metadata OWNER TO yg;

--
-- Name: makers; Type: TABLE; Schema: public; Owner: yg
--

CREATE TABLE makers (
    id integer NOT NULL,
    brand character varying NOT NULL,
    code character varying,
    series character varying,
    model character varying,
    kind character varying NOT NULL,
    size character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE makers OWNER TO yg;

--
-- Name: makers_id_seq; Type: SEQUENCE; Schema: public; Owner: yg
--

CREATE SEQUENCE makers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE makers_id_seq OWNER TO yg;

--
-- Name: makers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yg
--

ALTER SEQUENCE makers_id_seq OWNED BY makers.id;


--
-- Name: retailers; Type: TABLE; Schema: public; Owner: yg
--

CREATE TABLE retailers (
    id integer NOT NULL,
    maker_id integer,
    title character varying,
    price double precision,
    s_price double precision,
    in_stock boolean,
    description text,
    picture_url character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    merchant character varying,
    link character varying,
    dup integer DEFAULT 0
);


ALTER TABLE retailers OWNER TO yg;

--
-- Name: retailers_id_seq; Type: SEQUENCE; Schema: public; Owner: yg
--

CREATE SEQUENCE retailers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE retailers_id_seq OWNER TO yg;

--
-- Name: retailers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yg
--

ALTER SEQUENCE retailers_id_seq OWNED BY retailers.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: yg
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE schema_migrations OWNER TO yg;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: yg
--

ALTER TABLE ONLY makers ALTER COLUMN id SET DEFAULT nextval('makers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: yg
--

ALTER TABLE ONLY retailers ALTER COLUMN id SET DEFAULT nextval('retailers_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: yg
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/2164.dat';

--
-- Data for Name: makers; Type: TABLE DATA; Schema: public; Owner: yg
--

COPY makers (id, brand, code, series, model, kind, size, description, created_at, updated_at) FROM stdin;
\.
COPY makers (id, brand, code, series, model, kind, size, description, created_at, updated_at) FROM '$$PATH$$/2166.dat';

--
-- Name: makers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yg
--

SELECT pg_catalog.setval('makers_id_seq', 1, false);


--
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: yg
--

COPY retailers (id, maker_id, title, price, s_price, in_stock, description, picture_url, created_at, updated_at, merchant, link, dup) FROM stdin;
\.
COPY retailers (id, maker_id, title, price, s_price, in_stock, description, picture_url, created_at, updated_at, merchant, link, dup) FROM '$$PATH$$/2168.dat';

--
-- Name: retailers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yg
--

SELECT pg_catalog.setval('retailers_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: yg
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2163.dat';

--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: yg
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: makers_pkey; Type: CONSTRAINT; Schema: public; Owner: yg
--

ALTER TABLE ONLY makers
    ADD CONSTRAINT makers_pkey PRIMARY KEY (id);


--
-- Name: retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: yg
--

ALTER TABLE ONLY retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: yg
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: index_makers_on_code; Type: INDEX; Schema: public; Owner: yg
--

CREATE INDEX index_makers_on_code ON makers USING btree (code);


--
-- Name: index_retailers_on_maker_id; Type: INDEX; Schema: public; Owner: yg
--

CREATE INDEX index_retailers_on_maker_id ON retailers USING btree (maker_id);


--
-- Name: fk_rails_d5e06be6ba; Type: FK CONSTRAINT; Schema: public; Owner: yg
--

ALTER TABLE ONLY retailers
    ADD CONSTRAINT fk_rails_d5e06be6ba FOREIGN KEY (maker_id) REFERENCES makers(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

